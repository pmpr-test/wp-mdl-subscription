<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae9335956e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\141\x66\x74\145\162\137\145\156\161\165\145\165\145\x5f\142\141\x63\153\145\156\x64\137\141\x73\163\x65\x74\163", [$this, "\x65\x6e\x71\x75\x65\x75\x65"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\x64\155\x69\x6e", $eygsasmqycagyayw->get("\x61\x64\x6d\151\x6e\x2e\x6a\163"))->okawmmwsiuauwsiu()); } }
