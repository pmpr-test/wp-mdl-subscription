<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecb36f7b8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Module\Subscription\Setting; abstract class Common extends Page { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
