<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7c5c3ded             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Module\Subscription\Setting; abstract class Common extends Page { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
