<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d982153916             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Subscription\Model\Plan; use Pmpr\Module\Subscription\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Pricing extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x70\x72\x69\x63\x69\156\x67")->gswweykyogmsyawy(__("\x50\162\151\143\x69\x6e\147", PR__MDL__SUBSCRIPTION))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::usyscuksyoimmsyy)); parent::qiccuiwooiquycsg(); } public function rsysgcucogueguuk() : array { $omouioamescuegke = Plan::symcgieuakksimmu(); return ["\160\154\141\156\x73" => $omouioamescuegke->qyaiiayimwmuomey(), "\x66\145\x61\x74\x75\x72\x65\x5f\151\143\x6f\156" => IconInterface::ggokgkyiweugsokc, Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::ysgwugcqguggmigq), Constants::eqkeooqcsscoggia => $this->weysguygiseoukqw(Setting::bweaoswakkswcwms), Constants::uookioyeieiswoew => Constants::uookioyeieiswoew === $this->weysguygiseoukqw(Setting::quaagiciyoskcygq)]; } }
