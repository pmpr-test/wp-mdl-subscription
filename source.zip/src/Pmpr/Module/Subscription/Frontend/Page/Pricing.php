<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67235627e5491             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Subscription\Model\Plan; use Pmpr\Module\Subscription\Setting; use Pmpr\Common\Foundation\Frontend\Page; class Pricing extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x70\x72\x69\x63\x69\156\x67")->gswweykyogmsyawy(__("\x50\x72\151\x63\x69\x6e\147", PR__MDL__SUBSCRIPTION))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::usyscuksyoimmsyy)); parent::qiccuiwooiquycsg(); } public function rsysgcucogueguuk() : array { $omouioamescuegke = Plan::symcgieuakksimmu(); return ["\x70\x6c\x61\x6e\x73" => $omouioamescuegke->qyaiiayimwmuomey(), "\146\145\141\164\x75\162\x65\x5f\151\x63\157\156" => IconInterface::ggokgkyiweugsokc, Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::ysgwugcqguggmigq), Constants::eqkeooqcsscoggia => $this->weysguygiseoukqw(Setting::bweaoswakkswcwms), Constants::uookioyeieiswoew => Constants::uookioyeieiswoew === $this->weysguygiseoukqw(Setting::quaagiciyoskcygq)]; } }
