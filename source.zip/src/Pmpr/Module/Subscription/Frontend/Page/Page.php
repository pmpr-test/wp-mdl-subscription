<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae9335956e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend\Page; use Pmpr\Module\Subscription\Frontend\Common; class Page extends Common { public function mameiwsayuyquoeq() { Viewer::symcgieuakksimmu(); Pricing::symcgieuakksimmu(); } }
