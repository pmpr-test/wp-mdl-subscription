<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecb36f7b8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Frontend; use Pmpr\Module\Subscription\Container; abstract class Common extends Container { }
