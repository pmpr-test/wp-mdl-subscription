<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051797d12a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Subscription\Model; use Pmpr\Common\Foundation\ORM\Model; abstract class Common extends Model { }
